<button on:click={() => alert('clicked')}>
	Click me
</button>

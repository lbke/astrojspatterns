<button on:click|once={() => alert('clicked')}>
	Click me
</button>

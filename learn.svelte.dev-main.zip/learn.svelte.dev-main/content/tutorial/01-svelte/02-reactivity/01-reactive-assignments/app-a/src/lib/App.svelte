<script>
	let count = 0;

	function increment() {
		// event handler code goes here
	}
</script>

<button>
	Clicked {count}
	{count === 1 ? 'time' : 'times'}
</button>

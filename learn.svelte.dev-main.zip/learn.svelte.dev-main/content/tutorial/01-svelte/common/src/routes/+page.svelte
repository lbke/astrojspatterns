<script>
	import App from '$lib/App.svelte';
</script>

<App />

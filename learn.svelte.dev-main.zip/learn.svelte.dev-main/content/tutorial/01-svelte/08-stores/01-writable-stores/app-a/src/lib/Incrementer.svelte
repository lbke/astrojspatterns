<script>
	import { count } from './stores.js';

	function increment() {
		// TODO increment the count
	}
</script>

<button on:click={increment}>
	+
</button>

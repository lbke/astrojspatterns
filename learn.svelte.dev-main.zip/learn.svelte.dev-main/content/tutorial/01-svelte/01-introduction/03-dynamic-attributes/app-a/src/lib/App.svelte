<script>
	let src = '/image.gif';
</script>

<img />

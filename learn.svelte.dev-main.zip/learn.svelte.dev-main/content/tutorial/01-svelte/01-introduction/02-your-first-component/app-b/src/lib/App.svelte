<script>
	let name = 'Svelte';
</script>

<h1>Hello {name.toUpperCase()}!</h1>

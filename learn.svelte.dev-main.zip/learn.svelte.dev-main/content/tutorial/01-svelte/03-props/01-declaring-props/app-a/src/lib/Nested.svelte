<script>
	let answer;
</script>

<p>The answer is {answer}</p>

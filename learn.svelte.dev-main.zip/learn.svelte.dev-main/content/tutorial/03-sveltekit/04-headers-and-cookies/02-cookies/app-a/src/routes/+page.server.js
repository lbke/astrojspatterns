export function load() {
	const visited = 'false';

	return {
		visited: visited === 'true'
	};
}

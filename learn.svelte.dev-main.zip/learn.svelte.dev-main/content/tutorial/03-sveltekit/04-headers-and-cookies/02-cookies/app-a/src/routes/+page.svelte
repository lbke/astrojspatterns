<script>
	export let data;
</script>

<h1>Hello {data.visited ? 'friend' : 'stranger'}!</h1>
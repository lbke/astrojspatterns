export function load({ setHeaders }) {
	setHeaders({
		'Content-Type': 'text/plain'
	});
}

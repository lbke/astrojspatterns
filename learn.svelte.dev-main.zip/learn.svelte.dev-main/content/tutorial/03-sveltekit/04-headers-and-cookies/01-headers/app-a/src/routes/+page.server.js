export function load() {
	// set headers
}

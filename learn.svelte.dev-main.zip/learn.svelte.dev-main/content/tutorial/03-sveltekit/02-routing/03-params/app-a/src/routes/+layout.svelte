<nav>
	<a href="/">home</a>
	<a href="/blog">blog</a>
</nav>

<slot />

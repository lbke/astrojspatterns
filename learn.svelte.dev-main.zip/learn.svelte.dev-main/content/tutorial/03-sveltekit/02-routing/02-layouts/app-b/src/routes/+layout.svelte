<nav>
	<a href="/">home</a>
	<a href="/about">about</a>
</nav>

<slot />

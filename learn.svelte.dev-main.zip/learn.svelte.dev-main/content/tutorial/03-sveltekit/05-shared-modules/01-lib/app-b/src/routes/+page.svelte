<script>
	import { message } from '$lib/message.js';
</script>

<h1>home</h1>
<p>{message}</p>
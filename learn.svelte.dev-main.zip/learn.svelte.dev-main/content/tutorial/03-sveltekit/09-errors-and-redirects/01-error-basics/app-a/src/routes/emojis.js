export const emojis = {
	// TODO add the rest!
	420: '🫠',
	500: '💥'
};
export function load() {
	throw new Error(
		'Something went terribly wrong loading the about page'
	);
}

export function handleError() {
	return { message: 'Internal Error' }; // the default implementation of this hook
}

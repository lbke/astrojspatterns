export function load() {
	throw new Error('yikes');
}

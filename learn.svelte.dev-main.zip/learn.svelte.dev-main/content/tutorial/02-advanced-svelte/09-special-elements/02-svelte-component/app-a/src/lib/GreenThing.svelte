<p>Green thing</p>

<style>
	p {
		color: green;
	}
</style>

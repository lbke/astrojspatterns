<p>Blue thing</p>

<style>
	p {
		color: blue;
	}
</style>

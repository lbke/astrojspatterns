<p>Red thing</p>

<style>
	p {
		color: red;
	}
</style>

<script>
	import Box from './Box.svelte';
</script>

<div class="boxes">
	<Box />
	<Box />
	<Box />
</div>
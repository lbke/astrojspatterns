<script>
	import Card from './Card.svelte';
</script>

<main>
	<Card>
		<!-- content goes here -->
	</Card>
</main>

<style>
	main {
		display: grid;
		place-items: center;
		height: 100%;
		background: url(./wood.svg);
	}
</style>
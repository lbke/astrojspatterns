export function GET() {
	return new Response('hello from a');
}
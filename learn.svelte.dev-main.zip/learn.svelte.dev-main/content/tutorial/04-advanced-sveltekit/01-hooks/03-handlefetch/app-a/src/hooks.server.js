export async function handleFetch({ event, request, fetch }) {
	return await fetch(request);
}
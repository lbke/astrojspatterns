export function load() {
	throw new Error('this is the bad place!');
}
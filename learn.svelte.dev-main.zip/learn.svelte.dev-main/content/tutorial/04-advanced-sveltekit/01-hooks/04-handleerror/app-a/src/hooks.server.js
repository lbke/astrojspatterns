export function handleError({ event, error }) {
	console.error(error.stack);
}
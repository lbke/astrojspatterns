<script>
	export let data;
</script>

<h1>{data.message}</h1>
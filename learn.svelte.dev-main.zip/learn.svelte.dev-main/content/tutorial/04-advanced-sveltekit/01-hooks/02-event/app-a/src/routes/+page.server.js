export function load() {
	return {
		message: `the answer is ???`
	};
}
export const trailingSlash = 'always';

<h1>{window.innerWidth}x{window.innerHeight}</h1>
